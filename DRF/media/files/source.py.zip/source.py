import csv
import hashlib
import collections
def hash_password_hack(input_file_name, output_file_name):
    a = []
    z = []
    with open('input_file_name') as f:
        reader = csv.reader(f)
        for row in reader:
            row
            name = row[0]
            a = a + [name]
            pas = row[1]
            z = z + [pas]
    d = collections.OrderedDict()     
    for i in range(1000,10000):
        d[hashlib.sha256(str(i).encode()).hexdigest()] = i
    f = open('output_file_name','w')
    for i in range(0,len(z)):
        if i != len(z)-1:
            f.write('%s,%i\n'%(a[i],d[z[i]]))
        elif i == len(z)-1:
            f.write('%s,%i'%(a[i],d[z[i]]))   
    f.close()